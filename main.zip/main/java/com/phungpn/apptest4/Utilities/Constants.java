package com.phungpn.apptest4.Utilities;

/**
 * Created by sev_user on 04/08/2017.
 */

public class Constants {
    public static final int INTERVAL = (86400*1000)/4;
}
