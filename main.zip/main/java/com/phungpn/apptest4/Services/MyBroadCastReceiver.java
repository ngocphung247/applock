package com.phungpn.apptest4.Services;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by sev_user on 08/08/2017.
 */

public class MyBroadCastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")){
            Intent serviceLaucher= new Intent(context,MyService.class);
            context.startService(serviceLaucher);
        }
    }



}
