package com.phungpn.apptest4.Services;

import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.phungpn.apptest4.Activity.PasswordActivity;
import com.phungpn.apptest4.Activity.PasswordDialogActivity;
import com.phungpn.apptest4.Data.DatabaseHandler;

import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;


/**
 * Created by sev_user on 08/08/2017.
 */

public class MyService extends Service {
    Timer t = new Timer();
    public Boolean userAuth = false;
    private Context ctx;
    public String pActivity;
    Messenger mActivityManager;
    String activityOnTop;
    List<ActivityManager.RunningAppProcessInfo> RunningTask;
    Set<String> activePackages;
    ActivityManager.RunningAppProcessInfo ar;
    String topPackageName = null;
    PackageManager packageManager;
    String sosanh = "";
    String packageSend;
    public static DatabaseHandler databaseHandler;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        databaseHandler = new DatabaseHandler(this);
        super.onCreate();

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (!isAccessGranted()) {
            Intent i = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } else {
            fucked();
        }

        return START_STICKY;
    }

    public void fucked() {
        t.scheduleAtFixedRate(new mainTask(), 0, 3000);
    }

    private class mainTask extends TimerTask {

        @Override
        public void run() {
            toastHandler.sendEmptyMessage(0);
        }
    }

    @Override
    public void onDestroy() {
        Toast.makeText(this, "Stop", Toast.LENGTH_SHORT).show();
        super.onDestroy();
    }

    private final Handler toastHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {


            ctx = MyService.this;
            if (Build.VERSION.SDK_INT >= 21) {
                UsageStatsManager mUsageStatsManager = (UsageStatsManager) ctx.getSystemService(Context.USAGE_STATS_SERVICE);
                long time = System.currentTimeMillis();
                // We get usage stats for the last 10 seconds
                List<UsageStats> stats = mUsageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, time - 1000 * 10, time);
                // Sort the stats by the last time used
                if (stats != null) {
                    SortedMap<Long, UsageStats> mySortedMap = new TreeMap<Long, UsageStats>();
                    for (UsageStats usageStats : stats) {
                        mySortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                    }
                    if (!mySortedMap.isEmpty()) {
                        topPackageName = mySortedMap.get(mySortedMap.lastKey()).getPackageName();
                    }
                }
            }


            if (sosanh.equals(topPackageName) || (sosanh.equals("com.phungpn.apptest4"))) {
                Log.e("ketqua", "trung");
                sosanh = topPackageName;
            } else {
                if ((databaseHandler.checkNameApp(topPackageName))) {
                    Log.e("abc", topPackageName);
//                    .getData(topPackageName);
                    Intent i = new Intent(MyService.this, PasswordDialogActivity.class);
                    i.putExtra("package", topPackageName);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                }
                sosanh = topPackageName;
            }



        }
//        public void Laucher(){
//            packageManager.getLaunchIntentForPackage(topPackageName);
//        }
//        public boolean isChange(String current) {
//            current = topPackageName;
//
//            return false;
//        }

    };

    private boolean isAccessGranted() {
        try {
            PackageManager packageManager = getPackageManager();
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(getPackageName(), 0);
            AppOpsManager appOpsManager = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = 0;
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                mode = appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        applicationInfo.uid, applicationInfo.packageName);
            }
            return (mode == AppOpsManager.MODE_ALLOWED);

        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
