package com.phungpn.apptest4.Data;

/**
 * Created by sev_user on 08/08/2017.
 */

public class ListAppLock {
    private  int id;
    private  String nameApp;

    public ListAppLock(){

    }
    public ListAppLock(int id, String nameapp) {
        this.id = id;
        this.nameApp = nameapp;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameApp() {
        return nameApp;
    }

    public void setNameApp(String nameapp) {
        this.nameApp = nameapp;
    }
}
