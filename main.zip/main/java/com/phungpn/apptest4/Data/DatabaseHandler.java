package com.phungpn.apptest4.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sev_user on 08/08/2017.
 */

public class DatabaseHandler extends SQLiteOpenHelper {


    private Context context;
    private static final int DATABASE_VERSION = 5;

    private static final String DATABASE_NAME = "appLock";

    private static final String TABLE_LIST_APP_LOCK = "listAppLock";

    private static final String TABLE_PASSWORD = "password";

    public DatabaseHandler(Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_LISTAPP_TABLE = "CREATE TABLE " + TABLE_LIST_APP_LOCK + " ("
                + "id" + " INTEGER PRIMARY KEY, "
                + "nameApp" + " TEXT )";
        sqLiteDatabase.execSQL(CREATE_LISTAPP_TABLE);
        String CREATE_PASSWORD_TABLE = "CREATE TABLE " + TABLE_PASSWORD + "("
                + "id" + " INTEGER PRIMARY KEY,"
                + "password" + " TEXT )";
        sqLiteDatabase.execSQL(CREATE_PASSWORD_TABLE);
//        Toast.makeText(context, "Create table!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertListAppLock(ListAppLock listApp) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("nameApp", listApp.getNameApp());

        // Inserting Row
        db.insert(TABLE_LIST_APP_LOCK, null, values);
        db.close(); // Closing database connection

    }

    //    public void insertPasswork(PassWord passWord) {
//        SQLiteDatabase db = this.getWritableDatabase();
//
//        ContentValues values = new ContentValues();
//        values.put("passwork", passWord.getPassword());
//
//        // Inserting Row
//        db.insert(TABLE_PASSWORD, null, values);
//        db.close(); // Closing database connection
//    }
    public void insertPassword(Password password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("password", password.getPassword());

        // Inserting Row
        db.insert(TABLE_PASSWORD, null, values);
        db.close(); // Closing database connection
    }

    public List<Password> getAllPassword() {
        List<Password> passwordList = new ArrayList<Password>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_PASSWORD;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Password contact = new Password();
                contact.setId(Integer.parseInt(cursor.getString(0)));
                contact.setPassword(cursor.getString(1));
                // Adding contact to list
                passwordList.add(contact);
            } while (cursor.moveToNext());
        }

        cursor.close();
        // return contact list
        return passwordList;
    }

    public String getPassword() {
        ArrayList<Password> passwordList = new ArrayList<Password>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_PASSWORD;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Password contact = new Password();
                contact.setId(Integer.parseInt(cursor.getString(0)));
                contact.setPassword(cursor.getString(1));
                // Adding contact to list
                passwordList.add(contact);
            } while (cursor.moveToNext());
        }
        cursor.close();
        // return contact list

        if (passwordList.isEmpty()) return "";
        else {
            String pass = passwordList.get(0).getPassword();
            return pass;
        }
    }

    public void deletePassword(Password pass) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_PASSWORD, "password" + " = ?",
                new String[]{pass.getPassword()});
        db.close();
    }
    public void deleteListAppLock(ListAppLock listApp) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_LIST_APP_LOCK, "nameApp" + " = ?",
                new String[]{listApp.getNameApp()});
        db.close();
    }

    public List<ListAppLock> getAllListAppLock() {
        List<ListAppLock> contactList = new ArrayList<ListAppLock>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_LIST_APP_LOCK;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ListAppLock contact = new ListAppLock();
                contact.setId(Integer.parseInt(cursor.getString(0)));
                contact.setNameApp(cursor.getString(1));
                // Adding contact to list
                contactList.add(contact);
            } while (cursor.moveToNext());
        }

        cursor.close();
        // return contact list
        return contactList;
    }

    public List<ListAppLock> getAllApp() {
        List<ListAppLock> appList = new ArrayList<ListAppLock>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_LIST_APP_LOCK;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ListAppLock listApp = new ListAppLock();
                listApp.setId(Integer.parseInt(cursor.getString(0)));
                listApp.setNameApp(cursor.getString(1));
                // Adding contact to list
                appList.add(listApp);
            } while (cursor.moveToNext());
        }

        cursor.close();
        // return contact list
        return appList;
    }

    public boolean checkNameApp(String nameApp) {
        String selectQuery = "SELECT  * FROM " + TABLE_LIST_APP_LOCK;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                ListAppLock contact = new ListAppLock();
                contact.setId(Integer.parseInt(cursor.getString(0)));
                contact.setNameApp(cursor.getString(1));
                // Adding contact to list
                if (nameApp.equals(contact.getNameApp())) {
                    cursor.close();
                    return true;
                }
            } while (cursor.moveToNext());
        }

        cursor.close();
        // return contact list
        return false;
    }
}
