package com.phungpn.apptest4.Data;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;

/**
 * Created by sev_user on 07/08/2017.
 */

public class AppInfo {
    private String appName,appPackageName;
    private Drawable appIcon;
    private boolean statusLock;
    public AppInfo(String appName, String appPackageName, Drawable appIcon, Boolean statusLock){
        this.appName = appName;
        this.appPackageName = appPackageName;
        this.appIcon = appIcon;
        this.statusLock = statusLock;
    }




    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppPackageName() {
        return appPackageName;
    }

    public void setAppPackageName(String appPackageName) {
        this.appPackageName = appPackageName;
    }

    public Drawable getAppIcon() {
        return appIcon;
    }

    public void setAppIcon(Drawable appIcon) {
        this.appIcon = appIcon;
    }

    public boolean isStatusLock() {
        return statusLock;
    }

    public void setStatusLock(boolean statusLock) {
        this.statusLock = statusLock;
    }

    public Intent getLaunchIntent (Context context){

        Intent intentLaunch = context.getPackageManager().getLaunchIntentForPackage(this.appPackageName);
        return intentLaunch;
    }

}
