package com.phungpn.apptest4.Activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.phungpn.apptest4.Data.DatabaseHandler;
import com.phungpn.apptest4.R;
import com.phungpn.apptest4.Services.MyBroadCastReceiver;


import static com.phungpn.apptest4.Services.MyService.databaseHandler;

public class PasswordActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0, btnExit, btnDel;
    private TextView etPassword1, etPassword2, etPassword3, etPassword4;
    private Context mContext;
    private String myPassword = "";
    String packageNamed;
    private MyBroadCastReceiver myBroadcastReceiver;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
        databaseHandler = new DatabaseHandler(this);
        if (databaseHandler.getPassword().equals("")){
            TextView textView = (TextView) findViewById(R.id.tvEnterPassword);
            textView.setText(R.string.tv_set_password);
        }
        Init();
        mContext = this;
        //overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);


    }

    public void Init() {
        btn0 = (Button) findViewById(R.id.button0);
        btn1 = (Button) findViewById(R.id.button1);
        btn2 = (Button) findViewById(R.id.button2);
        btn3 = (Button) findViewById(R.id.button3);
        btn4 = (Button) findViewById(R.id.button4);
        btn5 = (Button) findViewById(R.id.button5);
        btn6 = (Button) findViewById(R.id.button6);
        btn7 = (Button) findViewById(R.id.button7);
        btn8 = (Button) findViewById(R.id.button8);
        btn9 = (Button) findViewById(R.id.button9);
        btnExit = (Button) findViewById(R.id.buttonExit);
        btnDel = (Button) findViewById(R.id.buttonDeleteBack);
        etPassword1 = (TextView) findViewById(R.id.etPassword1);
        etPassword2 = (TextView) findViewById(R.id.etPassword2);
        etPassword3 = (TextView) findViewById(R.id.etPassword3);
        etPassword4 = (TextView) findViewById(R.id.etPassword4);
        btn0.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btnExit.setOnClickListener(this);
        btnDel.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button0:
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("0");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("0");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("0");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("0");

                    DoSomeThing();
                }
                break;
            case R.id.button1:
                //my code
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("1");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("1");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("1");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("1");

                    DoSomeThing();
                }
                break;
            case R.id.button2:
                //my code
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("2");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("2");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("2");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("2");

                    DoSomeThing();
                }
                break;
            case R.id.button3:
                //my code
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("3");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("3");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("3");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("3");
                    DoSomeThing();
                }
                break;
            case R.id.button4:
                //my code
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("4");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("4");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("4");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("4");
                    DoSomeThing();
                }
                break;
            case R.id.button5:
                //my code
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("5");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("5");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("5");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("5");
                    DoSomeThing();
                }
                break;
            case R.id.button6:
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("6");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("6");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("6");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("6");
                    DoSomeThing();
                }

                //my code
                break;
            case R.id.button7:

                //my code
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("7");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("7");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("7");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("7");
                    DoSomeThing();
                }
                break;
            case R.id.button8:
                //my code
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("8");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("8");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("8");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("8");
                    DoSomeThing();
                }
                break;
            case R.id.button9:
                //my code
                if (etPassword1.getText().length() == 0)
                    etPassword1.setText("9");
                else if (etPassword2.getText().length() == 0)
                    etPassword2.setText("9");
                else if (etPassword3.getText().length() == 0)
                    etPassword3.setText("9");
                else if (etPassword4.getText().length() == 0) {
                    etPassword4.setText("9");
                    DoSomeThing();
                }
                break;
            case R.id.buttonExit:
                finish();
                //my code
                break;
            case R.id.buttonDeleteBack:
                //my code
                if (etPassword4.getText().length() == 1)
                    etPassword4.setText("");
                else if (etPassword3.getText().length() == 1)
                    etPassword3.setText("");
                else if (etPassword2.getText().length() == 1)
                    etPassword2.setText("");
                else if (etPassword1.getText().length() == 1)
                    etPassword1.setText("");
                break;
        }

    }

    public void DoSomeThing() {
        myPassword = etPassword1.getText().toString() + etPassword2.getText() + etPassword3.getText() + etPassword4.getText();
        if (databaseHandler.getPassword().equals("")){
            Intent intent = new Intent(this, PasswordSetActivity.class);
            intent.putExtra("pass", myPassword);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            this.startActivity(intent);
            finish();
        } else {
            String pass = databaseHandler.getPassword();
            if (myPassword.equals(pass)) {
                Intent intent = new Intent(this, MainActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent);
                finish();

            } else {
                Toast.makeText(mContext, "Error Password !", Toast.LENGTH_SHORT).show();
                etPassword1.setText("");
                etPassword2.setText("");
                etPassword3.setText("");
                etPassword4.setText("");
            }
        }
    }
}
