package com.phungpn.apptest4.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

import com.phungpn.apptest4.Data.DatabaseHandler;
import com.phungpn.apptest4.Data.ListAppLock;
import com.phungpn.apptest4.Data.Password;
import com.phungpn.apptest4.R;
import com.phungpn.apptest4.Services.MyService;

import java.util.ArrayList;

import static com.phungpn.apptest4.Services.MyService.databaseHandler;

public class MainActivity extends AppCompatActivity {

    private ViewPager mViewPager;
    private TabLayout mTabLayout;
    private Toolbar toolbar;
//    public static DatabaseHandler databaseHandlerPhu;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

//

        mViewPager = (ViewPager) findViewById(R.id.view_pager);
        mTabLayout = (TabLayout) findViewById(R.id.tab_layout);
        FragmentManager fragmentManager = getSupportFragmentManager();
        PagerAdapter pagerAdapter = new com.phungpn.apptest4.Adapter.PagerAdapter(MainActivity.this, fragmentManager);
        mViewPager.setAdapter(pagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(mTabLayout));
        mTabLayout.setTabsFromPagerAdapter(pagerAdapter);

        toolbar = (Toolbar) findViewById(R.id.toolbar);


        if (toolbar != null) {
            setSupportActionBar(toolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        toolbar.setTitle("App Lock BK");
        //overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        startService(new Intent(getBaseContext(),MyService.class));
        }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //stopService(new Intent(getBaseContext(),MyService.class));
    }
}

