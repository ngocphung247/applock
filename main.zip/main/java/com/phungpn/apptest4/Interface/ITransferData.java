package com.phungpn.apptest4.Interface;

/**
 * Created by sev_user on 04/08/2017.
 */

public interface ITransferData {
    public void onDataSelected(String data);
}
