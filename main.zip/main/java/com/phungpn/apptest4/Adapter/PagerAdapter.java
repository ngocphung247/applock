package com.phungpn.apptest4.Adapter;

/**
 * Created by sev_user on 04/08/2017.
 */

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.phungpn.apptest4.Fragment.AllAppFragment;
import com.phungpn.apptest4.Fragment.SettingFragment;
import com.phungpn.apptest4.R;


/**
 * Created by sev_user on 04/08/2017.
 */
public class PagerAdapter extends FragmentStatePagerAdapter {

    private Context mContext;



    public PagerAdapter(Context context, FragmentManager fm) {
        super(fm);
        this.mContext = context;


    }

    @Override
    public Fragment getItem(int position) {
        Fragment frag=null;
        switch (position){
            case 0:
                frag=new AllAppFragment();
                break;
            case 1:
                frag=new SettingFragment();
                break;
//            case 2:
//                frag=new AboutFragment();
//                break;
        }
        return frag;
    }

    @Override
    public int getCount() {
        return 2;
    }
    @Override
    public CharSequence getPageTitle(int position) {
        String title = "";
        switch (position){
            case 0:
                title=mContext.getResources().getString(R.string.all_app_fragment);

                break;
            case 1:
                title=mContext.getResources().getString(R.string.setting);
                break;
//            case 2:
//                title=mContext.getResources().getString(R.string.about);
//                break;
        }

        return title;
    }


}

