package com.phungpn.apptest4.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.phungpn.apptest4.Data.AppInfo;
import com.phungpn.apptest4.Data.ListAppLock;
import com.phungpn.apptest4.R;

import java.util.ArrayList;
import java.util.List;

import static com.phungpn.apptest4.Services.MyService.databaseHandler;

/**
 * Created by sev_user on 04/08/2017.
 */

public class ApplicationAdapter extends ArrayAdapter<AppInfo> {
    private List<AppInfo> appsList = new ArrayList();
    private Context context;

    private CheckBox switchLock;


    public ApplicationAdapter(Context context, int textViewResourceId, List<AppInfo> appsList) {
        super(context, textViewResourceId, appsList);
        this.appsList = appsList;
        this.context = context;

    }

    @Override
    public View getView(final int position, View view, ViewGroup parent) {
        ViewHolder holder = null;
        final AppInfo applicationInfo = appsList.get(position);
        if (null == view) {
            LayoutInflater layoutInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.snippet_list_row, null);
            holder = new ViewHolder();
            holder.appName = (TextView) view.findViewById(R.id.app_name);
            holder.packageName = (TextView) view.findViewById(R.id.app_package);
            holder.iconView = (ImageView) view.findViewById(R.id.app_icon);
            holder.switchLock = (CheckBox) view.findViewById(R.id.switchLock);
            view.setTag(holder);
            holder.appName.setText(applicationInfo.getAppName());
            holder.packageName.setText(applicationInfo.getAppPackageName());
            holder.iconView.setImageDrawable(applicationInfo.getAppIcon());
            holder.switchLock.setChecked(applicationInfo.isStatusLock());

            final ViewHolder finalHolder = holder;
            holder.switchLock.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    CheckBox cb = (CheckBox) v ;
                    AppInfo country = (AppInfo) cb.getTag();
                    if (cb.isChecked()){
                        Toast.makeText(context, finalHolder.appName.getText()+ " is locked", Toast.LENGTH_SHORT).show();
                        databaseHandler.insertListAppLock(new ListAppLock(1,finalHolder.packageName.getText().toString()));
                    } else {
                        databaseHandler.deleteListAppLock(new ListAppLock(1,finalHolder.packageName.getText().toString()));
                        Toast.makeText(context,finalHolder.appName.getText()+ " is unlocked", Toast.LENGTH_SHORT).show();
                    }
                    country.setStatusLock(cb.isChecked());
                }
            });

        } else {
            holder = (ViewHolder) view.getTag();
        }

        holder.appName.setText(applicationInfo.getAppName());
        holder.packageName.setText(applicationInfo.getAppPackageName());
        holder.iconView.setImageDrawable(applicationInfo.getAppIcon());
        holder.switchLock.setChecked(applicationInfo.isStatusLock());
        holder.switchLock.setTag(applicationInfo);
        return view;
    }

    static class ViewHolder {
        private TextView appName;
        private TextView packageName;
        private ImageView iconView;
        private CheckBox switchLock;

    }
}