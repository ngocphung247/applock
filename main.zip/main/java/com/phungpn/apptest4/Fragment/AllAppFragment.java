package com.phungpn.apptest4.Fragment;


import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.phungpn.apptest4.Adapter.ApplicationAdapter;
import com.phungpn.apptest4.Data.AppInfo;
import com.phungpn.apptest4.Data.ListAppLock;
import com.phungpn.apptest4.R;
import com.phungpn.apptest4.Services.MyService;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static com.phungpn.apptest4.Services.MyService.databaseHandler;


/**
 * A simple {@link Fragment} subclass.
 */
public class AllAppFragment extends Fragment implements Serializable {
    private PackageManager packageManager = null;
    private List<ApplicationInfo> applist = null;
    private ApplicationAdapter listadaptor = null;
    private ListView lvAllApp;

    public AllAppFragment() {

    }

    //@RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_all_app, container, false);

        lvAllApp = (ListView) view.findViewById(R.id.lvAllApp);

        packageManager = getActivity().getPackageManager();
        LoadApplications mTask = new LoadApplications();
        mTask.execute();

//        lvAllApp.setOnScrollChangeListener(new View.OnScrollChangeListener() {
//            @Override
//            public void onScrollChange(View view, int i, int i1, int i2, int i3) {
//
//            }
//        });

        return view;


    }

    private List<ApplicationInfo> checkForLaunchIntent(List<ApplicationInfo> list) {
        ArrayList<ApplicationInfo> applist = new ArrayList<ApplicationInfo>();
        for (ApplicationInfo info : list) {
            try {
                if (null != packageManager.getLaunchIntentForPackage(info.packageName)) {
                    applist.add(info);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return applist;
    }

    private class LoadApplications extends AsyncTask<Void, Void, Void> {
        private ProgressDialog progress = null;

        @Override
        protected Void doInBackground(Void... params) {
            ArrayList<AppInfo> installedApp = new ArrayList<AppInfo>();
            applist = checkForLaunchIntent(packageManager.getInstalledApplications(PackageManager.GET_META_DATA));


            for (ApplicationInfo App : applist) {
                int i = 1;
                if (!App.loadLabel(packageManager).toString().equals("LUCKY LOCK")) {
                    List<ListAppLock> contacts = databaseHandler.getAllListAppLock();
                    for (ListAppLock contact : contacts) {
                        String appName1 = contact.getNameApp();
                        if (App.packageName.equals(appName1)) {

                            installedApp.add(new AppInfo(App.loadLabel(packageManager).toString(), App.packageName, App.loadIcon(packageManager), true));
                            i = 0;
                            break;
                        }

                    }
                    if (i == 1)
                        installedApp.add(new AppInfo(App.loadLabel(packageManager).toString(), App.packageName, App.loadIcon(packageManager), false));
                }
            }
            listadaptor = new ApplicationAdapter(getActivity(), R.layout.snippet_list_row, installedApp);

            return null;
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }

        @Override
        protected void onPostExecute(Void result) {
            lvAllApp.setAdapter(listadaptor);
            lvAllApp.setTextFilterEnabled(true);

            progress.dismiss();
            super.onPostExecute(result);
        }

        @Override
        protected void onPreExecute() {
            progress = ProgressDialog.show(getActivity(), null,
                    "Loading application info...");
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }


}
