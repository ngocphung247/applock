package com.phungpn.apptest4.Fragment;


import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.phungpn.apptest4.Activity.PasswordActivity;
import com.phungpn.apptest4.Activity.PasswordDialogActivity;
import com.phungpn.apptest4.Activity.PasswordSetActivity;
import com.phungpn.apptest4.Data.Password;
import com.phungpn.apptest4.R;

import static com.phungpn.apptest4.Services.MyService.databaseHandler;

/**
 * A simple {@link Fragment} subclass.
 */
public class SettingFragment extends Fragment {

    private TextView tvPasswordChange, tvAbout;
    public SettingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_setting, container, false);

        tvPasswordChange = (TextView)view.findViewById(R.id.tvChangePassword);
        tvAbout = (TextView)view.findViewById(R.id.tvAbout);
        tvAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayAboutDialog();
            }
        });
        tvPasswordChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pass = databaseHandler.getPassword();
                databaseHandler.deletePassword(new Password(1,pass));
                Intent intent =  new Intent(getActivity(), PasswordActivity.class);
                startActivity(intent);
            }
        });
        return view;
    }
    private void displayAboutDialog() {
//        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
//        builder.setTitle("Ngoc Phung");
//        builder.setMessage("phungpn");
//
//        builder.setPositiveButton("Know More", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//                Toast.makeText(getActivity(), "", Toast.LENGTH_SHORT).show();
//                dialog.cancel();
//            }
//        });
//        builder.setNegativeButton("No Thanks!", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//                dialog.cancel();
//            }
//        });


//        builder.show();
        final Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.about_dialog);
        dialog.show();
    }
}
